const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "http://localhost:3001",
        methods: ["GET", "POST"]
    }
});

mongoose.connect('mongodb://localhost:27017/chat-app', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected successfully.'))
  .catch(err => console.error('Failed to connect to MongoDB:', err));

const roomSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    description: String,
    createdAt: { type: Date, default: Date.now }
});

const messageSchema = new mongoose.Schema({
    room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true },
    sender: String,
    message: String,
    createdAt: { type: Date, default: Date.now }
});

const Room = mongoose.model('Room', roomSchema);
const Message = mongoose.model('Message', messageSchema);

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('createRoom', async ({ name, description }) => {
        if (!name) {
            socket.emit('error', 'Room name is required.');
            return;
        }
        try {
            let room = await Room.findOne({ name });
            if (room) {
                socket.emit('error', 'Room already exists.');
                return;
            }
            room = new Room({ name, description });
            await room.save();
            socket.join(room._id.toString());
            socket.emit('roomCreated', { roomName: room.name, roomId: room._id });
        } catch (err) {
            console.error('Error creating room:', err);
            socket.emit('error', 'Error creating room: ' + err.message);
        }
    });

    socket.on('joinRoom', async ({ name }) => {
        try {
            const room = await Room.findOne({ name });
            if (!room) {
                socket.emit('error', 'Room not found.');
                return;
            }
            socket.join(room._id.toString());
            const messages = await Message.find({ room: room._id }).limit(10).sort({ createdAt: -1 });
            socket.emit('joinedRoom', { roomName: room.name, roomId: room._id, messages: messages.reverse() });
        } catch (err) {
            console.error('Error joining room:', err);
            socket.emit('error', 'Failed to join room: ' + err.message);
        }
    });

    socket.on('sendMessage', async ({ roomId, sender, message }) => {
        if (!roomId || !message) {
            socket.emit('error', 'Message and room ID are required.');
            return;
        }
        try {
            const newMessage = new Message({ room: roomId, sender, message });
            await newMessage.save();
            io.to(roomId).emit('newMessage', newMessage);
        } catch (err) {
            console.error('Error sending message:', err);
            socket.emit('error', 'Failed to send message: ' + err.message);
        }
    });

    socket.on('sendPrivateMessage', ({ toSocketId, message }) => {
        socket.to(toSocketId).emit('privateMessage', { message, sender: socket.id });
    });

    socket.on('typing', ({ roomId, sender }) => {
        socket.to(roomId).broadcast.emit('typing', { sender });
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

server.listen(3000, () => {
    console.log('Server running on port 3000');
});
